
public class Tester {
	public static void main(String[] args) {
		Person p = new Person();
	}
}
